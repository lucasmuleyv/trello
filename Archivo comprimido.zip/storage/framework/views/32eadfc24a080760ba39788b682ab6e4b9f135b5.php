<?php $__env->startSection('content'); ?>
    <input type="hidden" id="csrf_token" value="<?php echo e(csrf_token()); ?>" />
    <Trello></Trello>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/lucasmuley/PROYECTOS/UPWORK/trello/resources/views/trello.blade.php ENDPATH**/ ?>